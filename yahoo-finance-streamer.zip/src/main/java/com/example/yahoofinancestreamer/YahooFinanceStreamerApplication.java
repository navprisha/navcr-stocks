package com.example.yahoofinancestreamer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class YahooFinanceStreamerApplication {

	public static void main(String[] args) {
		SpringApplication.run(YahooFinanceStreamerApplication.class, args);
	}

}
