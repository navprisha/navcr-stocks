package com.example.yahoofinancestreamer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YahooFinanceStreamerApplicationTests {

	@Test
	void contextLoads() {
	}

}
